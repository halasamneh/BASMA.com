import logo from "../assets/images/logo2.png"
function Bottom() {
    return (
        <div className="">
            <div className="pt-12 bg-gray-700 text-gray-300 ">
                <div>
                    <div className="w-9/12 mx-auto grid grid-cols-4 gap-3">
                        <div>
                            <img src={logo} alt="" className="w-12" />
                            <p className="text-xs mt-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                        </div>
                        <div>
                            <h1 className="text-white mb-2 text-lg">About</h1>
                            <p className="text-xs">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">About us</span>
                            </p>
                            <p className="text-xs my-2">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">Contact</span>
                            </p>
                            <p className="text-xs">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">Portfolio</span>
                            </p>
                        </div>
                        <div>
                            <h1 className="text-white mb-2 text-lg">Support</h1>
                            <p className="text-xs">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">support@example.com</span>
                            </p>
                            <p className="text-xs my-2">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">+65 7 8796 5453</span>
                            </p>
                            <p className="text-xs">
                                <i class="lni lni-angle-double-right text-xs"></i>
                                <span className="ml-2">Services</span>
                            </p>
                        </div>
                        <div>
                            <h1 className="text-white mb-2 text-lg">Follow us</h1>
                            <p className="text-xs">
                                <i class="lni lni-facebook-filled text-xs"></i>
                                <span className="ml-2">Facebook</span>
                            </p>
                            <p className="text-xs my-2">
                                <i class="lni lni-twitter-filled text-xs"></i>
                                <span className="ml-2">Twitter</span>
                            </p>
                            <p className="text-xs">
                                <i class="lni lni-instagram text-xs"></i>
                                <span className="ml-2">Instagram</span>
                            </p>
                        </div>
                    </div>
                </div>
                <p className="text-white text-center py-4 font-light border-t border-gray-500 mt-12 text-sm">
                    Copyright All Right Reserved
                </p>
            </div>
        </div>
    );
}

export default Bottom;