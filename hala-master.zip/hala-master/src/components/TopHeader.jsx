import bg from "../assets/images/bg-intro.png"
import logo from "../assets/images/logo.png"
import banner from "../assets/images/banner.png"
import { useState } from "react"
function TopHeader() {
    function changeLocale() {
        const d = document.body.dir;
        document.body.dir = d === "rtl" ? "ltr" : "rtl"
        d === "rtl" ? setDir("ltr") : setDir("rtl")
    }
    const [dir, setDir] = useState("ltr")
    return (
        <div className=" bg-indigo-50 pb-4">
            <div className="flex  justify-between w-9/12 mx-auto">
                <div>
                    <img src={logo} alt="" className="py-4 w-14 " />
                    <button onClick={() => changeLocale()} >
                        {
                            dir === "ltr" ? "تغيير اللغة" : "Change locale"
                        }
                    </button>
                    <div className={`flex items-center pt-14 ${dir === "rtl" && "flex-row-reverse  justify-end"}`} >
                        <div className=" w-14 bg-indigo-500" style={{ height: "2px" }}></div>
                        <div className="w-2"></div>
                        <h2 className={` text-xl`}>WELCOME TO OYA</h2>
                    </div>

                    <div className="py-10">
                        <h1 className="text-indigo-50 font-black" style={{ WebkitTextStroke: "2px #614caa", fontSize: "70px", letterSpacing: "8px", lineHeight: "80px" }}>A DIGITAL <br /> AGENCY</h1>
                    </div>

                    <div className="text-sm flex">
                        <button className="bg-yellow-400 text-white  py-2 px-6 rounded">Get Started</button>
                        <div className="w-4"></div>
                        <button className=" py-2 px-6 border border-yellow-400  rounded">Get Started</button>
                    </div>
                </div>
                <div className="relative w-6/12 flex-grow">
                    <img src={bg} alt="" className={`w-full`} style={{ transform: `${dir === "rtl" ? "rotateY(180deg)" : "rotateY(0deg)"}` }} />
                    <img src={banner} className=" w-72 rounded-2xl absolute top-32  right-40" alt="" />
                    <div className="absolute top-0 w-full text-white  flex justify-center  py-4 text-sm">
                        <span className="px-2">Home</span>
                        <span className="px-2">About</span>
                        <span className="px-2">Services</span>
                        <span className="px-2">Portfolio</span>
                        <span className="px-2">Pricing</span>
                        <span className="px-2">Contact us</span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default TopHeader;