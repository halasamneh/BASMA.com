function Services() {
    const blocks = [
        {
            heading: "Wordpress",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-wordpress"
        }
        ,
        {
            heading: "Logo Design",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-vector"

        },
        {
            heading: "Online Seo",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-keyword-research"

        },
        {
            heading: "Mobile Apps",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-mobile"
        }
        ,
        {
            heading: "Copywriting",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-list"

        },
        {
            heading: "Brand Strategy",
            body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores dolor sint illo. Aliquam culpa distinctio libero quia fuga",
            icon: "lni lni-bulb"

        }
    ]
    return (
        <div className="bg-gray-100 py-24 text-center ">
            <h2 className="text-sm text-indigo-500">SERVICES</h2>
            <p className=" font-semibold text-2xl mt-4">Choose what <br /> You like our services</p>
            <div className="flex items-center w-10/12 mx-auto mt-8 flex-wrap justify-center">
                {
                    blocks.map((block) => (
                        <div key={block.heading} className=" bg-white mx-4 rounded-lg py-6 px-4 w-3/12 mb-5">
                            <i className={`text-5xl  text-indigo-500 mb-2 ${block.icon}`}></i>
                            <h1 className="font-medium text-lg mb-2">{block.heading}</h1>
                            <p className="text-gray-500 text-sm">{block.body}</p>
                        </div>
                    ))
                }
            </div>
        </div>
    );
}

export default Services;