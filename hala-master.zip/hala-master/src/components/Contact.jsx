function Contact() {
    return (
        <div className="py-24 w-9/12 mx-auto">
            <div className="flex">
                <div className="w-3/12">
                    <div className="flex flex-col justify-between">
                        <div>
                            <h1 className="font-semibold mb-2">Address</h1>
                            <p className=" font-light text-gray-400 text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
                        </div>
                        <div className="my-5">
                            <h1 className="font-semibold mb-2">Phone</h1>
                            <p className=" font-light text-gray-400 text-sm">+21 3 4343 9898</p>
                        </div>
                        <div>
                            <h1 className="font-semibold mb-2">Email</h1>
                            <p className=" font-light text-gray-400 text-sm">support@example.com</p>
                        </div>
                    </div>
                </div>
                <div className="flex-grow pl-10 text-sm">
                    <div className="flex justify-between pb-4">
                        <input type="text" placeholder="Name" className="h-10 bg-gray-100 px-4 rounded-md block" style={{ width: "48%" }} />
                        <input type="text" placeholder="Email address" className="h-10 bg-gray-100 px-4 rounded-md block" style={{ width: "48%" }} />
                    </div>
                    <div className="pb-4">
                        <input type="text" placeholder="Subject" className="h-10 bg-gray-100 px-4 rounded-md block w-full" />
                    </div>
                    <div>
                        <textarea placeholder="Message" className=" pt-2 h-40 bg-gray-100 px-4 rounded-md block w-full"></textarea>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Contact;