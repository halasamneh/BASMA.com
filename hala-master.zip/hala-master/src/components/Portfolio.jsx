import { useState } from "react";
import p1 from "../assets/images/portfolio1.jpeg"
import p2 from "../assets/images/portfolio2.jpeg"
import p3 from "../assets/images/portfolio3.jpeg"
import p4 from "../assets/images/portfolio4.jpeg"
import p5 from "../assets/images/portfolio5.jpeg"
import p6 from "../assets/images/portfolio6.jpeg"
function Portfolio() {
    const types = [
        {
            title: "SHOW ALL",
            images: [p1, p2, p3, p4, p5, p6]
        },
        {
            title: "GRAPHIC",
            images: [p1, p2]

        },
        {
            title: "LANDING",
            images: [p3, p4]
        },
        {
            title: "ART DESIGN",
            images: [p5, p6]
        }
    ]
    const [active, setActive] = useState(
        {
            title: "SHOW ALL",
            images: [p1, p2, p3, p4, p5, p6]
        }
    )
    return (
        <div className="py-24">
            <h2 className="text-sm text-indigo-500 text-center">PORTFOLIO</h2>
            <p className=" text-center font-semibold text-2xl mt-4">See our <span className="text-white" style={{ WebkitTextStroke: "1px #614caa" }}>amazing</span> <br /> <span className="text-white" style={{ WebkitTextStroke: "1px #614caa" }}>portfolio</span> collection</p>
            <div className="flex justify-center pt-12">
                <div className="space-x-6 text-sm">
                    {
                        types.map((type) => (
                            <button onClick={() => setActive(type)} key={type.title} className={`py-2 px-4 rounded-md border border-indigo-600  ${type.title === active.title ? 'bg-indigo-600 text-white' : ' text-indigo-600'}`}>{type.title}</button>
                        ))
                    }
                </div>
            </div>
            <div className=" grid grid-cols-3 gap-4 mt-12 w-9/12 mx-auto">
                {
                    active.images.map((img) => (
                        <img src={img}  className="block rounded-xl mb-2 w-full"  alt=""/>
                    ))
                }
            </div>
        </div>
    );
}

export default Portfolio;