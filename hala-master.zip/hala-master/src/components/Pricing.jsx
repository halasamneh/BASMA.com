function Pricing() {
    const plans = [
        {
            title: "Basic",
            price: "15$",
            bg: "bg-gray-100",
            priceColor: "text-indigo-600",
            titleColor: "text-black",
            activeColor:"text-black",
            inactiveColor:"text-gray-300",
            desc: [
                {
                    title: "Responsive",
                    active: true,
                },
                {
                    title: "Documentation",
                    active: true,
                },
                {
                    title: "Support",
                    active: false,
                },
                {
                    title: "Creative",
                    active: false,
                },
                {
                    title: "Modern",
                    active: false,
                },
                {
                    title: "Free Update",
                    active: false,
                },
            ]
        },
        {
            title: "Standart",
            price: "30$",
            bg: "bg-indigo-600",
            priceColor: "text-white",
            titleColor: "text-white",
            activeColor:"text-white",
            inactiveColor:"text-gray-400",
            desc: [
                {
                    title: "Responsive",
                    active: true,
                },
                {
                    title: "Documentation",
                    active: true,
                },
                {
                    title: "Support",
                    active: true,
                },
                {
                    title: "Creative",
                    active: false,
                },
                {
                    title: "Modern",
                    active: false,
                },
                {
                    title: "Free Update",
                    active: false,
                },
            ]
        },
        {
            title: "Premium",
            price: "50$",
            bg: "bg-gray-200",
            titleColor: "text-black",
            priceColor: "text-indigo-600",

            desc: [
                {
                    title: "Responsive",
                    active: true,
                },
                {
                    title: "Documentation",
                    active: true,
                },
                {
                    title: "Support",
                    active: true,
                },
                {
                    title: "Creative",
                    active: true,
                },
                {
                    title: "Modern",
                    active: true,
                },
                {
                    title: "Free Update",
                    active: true,
                },
            ]
        }
    ]
    return (
        <div className="py-24">
            <h2 className="text-sm text-indigo-500 text-center">PRICING TABLE</h2>
            <p className=" font-semibold text-2xl mt-4 text-center">Your plance, your choise</p>
            <div className="w-9/12 grid grid-cols-3 gap-4 mx-auto mt-12">
                {
                    plans.map((plan) => (
                        <div key={plan.title} className={`relative text-center pb-10 rounded-bl-xl rounded-br-xl ${plan.bg}`}>
                            <h1 className={`${plan.titleColor} text-xl mt-1`}>{plan.title}</h1>
                            <p className={`${plan.priceColor} text-2xl font-semibold my-4`}>{plan.price}</p>
                            {
                                plan.desc.map(
                                    (desc) => (
                                        <p className={`my-3 ${desc.active ? plan.activeColor : plan.inactiveColor}`} key={plan.title + desc.title}>{desc.title}</p>
                                    )
                                )
                            }
                            <div className="absolute -bottom-4   flex w-full justify-center">
                            <button className=" bg-yellow-400 text-white px-4 py-2 rounded-md">Get started</button>
                            </div>
                        </div>
                    ))
                }
            </div>
        </div>
    );
}

export default Pricing;