import Aboutus from "./components/Aboutus";
import Bottom from "./components/Bottom";
import Contact from "./components/Contact";
import Portfolio from "./components/Portfolio";
import Pricing from "./components/Pricing";
import Services from "./components/Services";
import TopHeader from "./components/TopHeader";

function App() {

  return (
    <div className="container mx-auto text-gray-700 transition-all ">
      <TopHeader />
      <Aboutus />
      <Portfolio />
      <Services />
      <Pricing />
      <Contact />
      <Bottom/>
    </div>
  );
}

export default App;
